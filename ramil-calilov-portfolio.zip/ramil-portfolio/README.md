# Ramil Calilov — Multilingual Portfolio

Three-language personal research portfolio:
- Azərbaycan dili (default)
- Türkçe
- English

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

Push this folder to GitHub and import the repository in Vercel. No special environment variables are required.

## Main files
- `app/page.tsx` — portfolio content + language switcher
- `app/globals.css` — visual design
- `public/profile.jpeg` — profile photo extracted from the supplied CV
- `public/Ramil-Celilov-CV.pdf` — CV download

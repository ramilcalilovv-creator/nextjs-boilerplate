import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Ramil Calilov | Researcher & Political/Security Analyst',
  description: 'Ramil Calilov — researcher focused on geopolitics, security studies, strategic research and public policy.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="az"><body>{children}</body></html>;
}
